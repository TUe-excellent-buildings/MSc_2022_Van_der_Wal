#ifndef BSO_GRAMMAR_PROPERTY_BASE_CPP
#define BSO_GRAMMAR_PROPERTY_BASE_CPP

namespace bso { namespace grammar { namespace rule_set {

property_base::property_base()
{
	
} // ctor()

property_base::~property_base()
{
	
} // dtor()
	
} // namespace rule_set
} // namespace grammar
} // namespace bso

#endif // BSO_GRAMMAR_PROPERTY_BASE_CPP